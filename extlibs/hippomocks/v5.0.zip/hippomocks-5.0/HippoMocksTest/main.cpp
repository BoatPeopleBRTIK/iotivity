#include "Framework.h"

int main(int , char **) {
    return TestRegistry::Instance().RunTests();
}



