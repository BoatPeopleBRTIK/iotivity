Hippomocks ![Build status](https://travis-ci.org/dascandy/hippomocks.svg?branch=master "Current build status on Travis CI")
==========

Single-header mocking framework.

